Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.6 ==
- [BUG] Fix video following style issue in video post template

== 6.0.5 ==
- [BUG] Fix notification popup style issue

== 6.0.4 ==
- [BUG] Fix naming folder issue
- [BUG] Fix issue with implode() function PHP 7.4

== 6.0.3 ==
- [IMPROVEMENT] Only load the style and script files when needed

== 6.0.2 ==
- [IMPROVEMENT] Change default only search video post to disable

== 6.0.1 ==
- [BUG] Fix active plugin issue
- [BUG] Fix customizer JNews Video empty

== 6.0.0 ==
- First Release
