Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.1 [Development] ==
- [IMPROVEMENT] Better Instagram handler

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [BUG] Fixed Instagram feed issue

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.1 ==
- [IMPROVEMENT] Support Instagram API to fetch Instagram feed
- [BUG] Fixed Instagram feed issue

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.1 ==
- [BUG] Fix feed issue

== 1.0.0 ==
- First Release
