Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0
- [BUG] Fix save issue on block editor
- [BUG] Fix script loaded on AMP page

== 6.0.1 ==
- [IMPROVEMENT] Only load the style and script file when needed
- [IMPROVEMENT] Add lazyload image for image ad

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.2 ==
- [BUG] Fix navigation arrow

== 5.0.1 ==
- [IMPROVEMENT] Use .on()

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0
- [NEW FEATURE] Double click expand for JNews Gallery

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.2 ==
- [BUG] Fix fullscreen mode issue

== 3.0.1 ==
- [IMPROVEMENT] Remove all white space on Google ad ID

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
