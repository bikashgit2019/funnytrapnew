(function ($) {

    'use strict'

    /**
     * Ajax send request for unlocking post
     */
    $(document).bind('ready jnews-ajax-load', function (e, data) {
        window.jnews.paywall = window.jnews.paywall || {}

        window.jnews.paywall = {
            init: function (container) {
                var base = this,
                    post_id,
                    user_login = $('body.logged-in')
                base.xhr = null

                if (container === undefined) {
                    base.container = $('body')
                } else {
                    base.container = container
                }

                /**
                 * Unlock Popup
                 */
                base.container.find('.jeg_paywall_unlock_post').unbind('click').on('click', function (e) {
                    post_id = $(this).data('id')
                    base.open_form(e, '#jpw_unlock_popup')
                })

                base.container.find('#jpw_unlock_popup .btn.yes').unbind('click').on('click', function (e) {
                    e.preventDefault()
                    e.stopPropagation()
                    var $element = $(this),
                        ajax_data = {
                            unlock_post_id: '1',
                            action: 'paywall_handler',
                            post_id: post_id
                        }
                    $element.find('.fa-spinner').show();
                    $element.find('span').hide();
                    if (base.xhr !== null) {
                        base.xhr.abort()
                    }
                    base.paywall_ajax(ajax_data)
                })

                base.container.find('#jpw_unlock_popup .btn.no').unbind('click').on('click', function (e) {
                    $.magnificPopup.close()
                })

                /**
                 * Cancel Subscription
                 */
                base.container.find('.jpw_manage_status .subscription').unbind('click').on('click', function (e) {
                    base.open_form(e, '#jpw_cancel_subs_popup')
                })

                base.container.find('#jpw_cancel_subs_popup .btn.yes').unbind('click').on('click', function (e) {
                    e.preventDefault()
                    e.stopPropagation()
                    var $element = $(this),
                        ajax_data = {
                            cancel_subscription: 'yes',
                            action: 'cancel_subs_handler',
                        }
                    $element.find('.fa-spinner').show();
                    $element.find('span').hide();
                    if (base.xhr !== null) {
                        base.xhr.abort()
                    }
                    base.paywall_ajax(ajax_data)
                })

                base.container.find('#jpw_cancel_subs_popup .btn.no').unbind('click').on('click', function (e) {
                    $.magnificPopup.close()
                })

                /**
                 * Login Needed
                 */
                base.container.find('.jpw_login a').unbind('click').on('click', function (e) {
                    var form = document.getElementsByClassName('jeg_accountlink')

                    if (form.length > 0) {
                        base.open_form(e, '#jeg_loginform')
                    } else {
                        e.preventDefault()
                        alert('Please login to buy!')
                    }
                })

                base.container.find('.jpw-wrapper .package-item .button').unbind('click').on('click', function (e) {
                    e.preventDefault()
                    e.stopPropagation()
                    var $element = $(this)
                    if (user_login.length == 0) {
                        var form = document.getElementsByClassName('jeg_accountlink')

                        if (form.length != 0) {
                            base.open_form(e, '#jeg_loginform')
                        } else {
                            alert('Please login to buy!')
                        }
                    } else {
                        var productID = $element.attr('data-product_id'),
                            ajax_data = {
                                product_id: productID,
                                action: 'add_paywall_product'
                            }
                        $element.find('.fa-spinner').show();
                        $element.find('span').hide();
                        if (base.xhr !== null) {
                            base.xhr.abort()
                        }
                        base.paywall_ajax(ajax_data)
                    }
                })

                base.container.find('.woocommerce-MyAccount-paymentMethods .stripepaywall .delete').unbind('click').on('click', function (e) {
                    e.preventDefault()
                    e.stopPropagation()
                    var $element = $(this)
                    var sourceID = $element.attr('data-source_id'),
                        ajax_data = {
                            source_id: sourceID,
                            action: 'delete_source_handler'
                        }
                    $element.find('.fa-spinner').show();
                    $element.find('span').hide();
                    if (base.xhr !== null) {
                        base.xhr.abort()
                    }
                    base.paywall_ajax(ajax_data)
                })

                base.container.find('.woocommerce-MyAccount-paymentMethods .stripepaywall .default').unbind('click').on('click', function (e) {
                    e.preventDefault()
                    e.stopPropagation()
                    var $element = $(this)
                    var sourceID = $element.attr('data-source_id'),
                        ajax_data = {
                            source_id: sourceID,
                            action: 'default_source_handler'
                        }
                    $element.find('.fa-spinner').show();
                    $element.find('span').hide();
                    if (base.xhr !== null) {
                        base.xhr.abort()
                    }
                    base.paywall_ajax(ajax_data)
                })
            },

            paywall_ajax: function (ajaxdata) {
                var base = this
                base.xhr = $.ajax({
                    url: jnews_ajax_url,
                    type: 'post',
                    dataType: 'json',
                    data: ajaxdata,
                }).done(function (data) {
                    if (data.redirect) {
                        window.location.href = data.redirect
                    } else {
                        location.reload()
                    }
                })
            },

            open_form: function (e, popup_id) {
                e.preventDefault()

                $.magnificPopup.open({
                    items: {
                        removalDelay: 500,
                        midClick: true,
                        src: popup_id,
                        type: 'inline'
                    }
                })
            },
        }

        jnews.paywall.init()
    })
})(jQuery)