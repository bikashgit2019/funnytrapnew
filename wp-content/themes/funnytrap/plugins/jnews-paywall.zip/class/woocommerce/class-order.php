<?php

/**
 * JNews Paywall Class
 *
 * @author Jegtheme
 * @since 1.0.0
 * @package jnews-paywall
 */

namespace JNews\Paywall\Woocommerce;

use DateTime;
use DateTimeZone;
use Exception;
use JNews\Paywall\Gateways\Paypal\Paypal_Api;
use JNews\Paywall\Gateways\Stripe\Stripe_Api;
use JPW_Paypal;
use JPW_Stripe;

/**
 * Class Order
 *
 * @package JNews\Paywall\Woocommerce
 */
class Order {
	/**
	 * @var Order
	 */
	private static $instance;

	/**
	 * Order constructor.
	 */
	private function __construct() {
		// actions.
		add_filter( 'woocommerce_payment_complete_order_status', [ $this, 'payment_complete_order_status' ], 99, 3 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'order_paid' ], 99, 3 );
		add_action( 'woocommerce_add_to_cart', [ $this, 'product_added' ], 10, 2 );
		add_action( 'woocommerce_before_thankyou', [ $this, 'auto_complete_order' ] );
	}

	/**
	 * @return Order
	 */
	public static function instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}


	/**
	 * Check if product already added in cart
	 *
	 * @param $cart_item_key
	 * @param $product_id
	 *
	 * @return mixed
	 */
	public function product_added( $cart_item_key, $product_id ) {

		foreach ( WC()->cart->get_cart() as $key => $cart_item ) {
			$item_data = $cart_item['data'];
			if ( 'paywall_subscribe' === $item_data->get_type() ) {
				if ( $product_id === $cart_item['product_id'] ) {
					WC()->cart->set_quantity( $key, 1 );
				} else {
					WC()->cart->set_quantity( $key, 0 );
				}
			} else {
				$product = wc_get_product( $product_id );
				if ( $product->get_type() === 'paywall_subscribe' ) {
					WC()->cart->set_quantity( $key, 0 );
				}
			}
		}

		return $cart_item_key;
	}

	/**
	 * Auto Complete Order
	 *
	 * Hooked into woocommerce_thankyou hook.
	 *
	 * @param $order_id
	 */
	public function auto_complete_order( $order_id ) {
		if ( ! $order_id ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( $order && 'paypalsubscribe' === $order->get_payment_method() && class_exists( 'WC_Payment_Gateway' ) ) {
			remove_action( 'woocommerce_order_details_after_order_table', 'woocommerce_order_again_button' );
			$credentials = new JPW_Paypal();
			$credentials->subscribe_status( $order_id );
		}
	}

	/**
	 * Product paywall unlock doesn't need processing.
	 * Make it completed !
	 *
	 * @param string $status order status.
	 * @param int $id unique ID for this object.
	 * @param \WC_Order $order Order class.
	 *
	 * @return string
	 */
	public function payment_complete_order_status( $status, $id, $order ) {
		foreach ( $order->get_items() as $item ) {
			if ( $item->is_type( 'line_item' ) ) {
				$product = $item->get_product();
				/** @var \WC_Product|bool $product */
				if ( $product && $product->is_type( 'paywall_unlock' ) ) {
					$status = 'completed';
				}
			}
		}

		return $status;
	}

	/**
	 * Order paid
	 *
	 * @param $order_id
	 * @param $old_status
	 * @param $new_status
	 *
	 * @throws Exception
	 */
	public function order_paid( $order_id, $old_status, $new_status ) {
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$user_id   = $order->get_customer_id() !== null ? $order->get_customer_id() : 0;
			$completed = false;

			$paywall_user_data = [];
			$is_paywall        = false;

			// paywall_subscribe variables.
			$subscribe_status   = get_user_option( 'jpw_subscribe_status', $user_id ) ? get_user_option( 'jpw_subscribe_status', $user_id ) : false;
			$expired            = get_user_option( 'jpw_expired_date', $user_id ) ? get_user_option( 'jpw_expired_date', $user_id ) : false;
			$paypalsubscribe_id = '';

			// paywall_unlock variables.
			$unlock_remaining = get_user_option( 'jpw_unlock_remaining', $user_id ) ? get_user_option( 'jpw_unlock_remaining', $user_id ) : 0;
			$unlocked_posts   = get_user_option( 'jpw_unlocked_post_list', $user_id) ? get_user_option( 'jpw_unlocked_post_list', $user_id ) : [];

			if ( $unlock_remaining < 0 ) {
				$unlock_remaining = 0;
			}

			foreach ( $order->get_items() as $item_id => $item ) {
				$product = wc_get_product( $item['product_id'] );

				// check if product is paywall_subscribe.
				if ( $product->is_type( 'paywall_subscribe' ) && $user_id > 0 ) {
					$is_paywall         = true;
					$paypalsubscribe_id = get_post_meta( $order_id, 'subscription_id', true );
					$stripesubscribe_id = get_post_meta( $order_id, 'jpw_stripe_subs_id', true );
					
					if ( $paypalsubscribe_id ) {
						$credentials        	= new JPW_Paypal();
						$request            	= new Paypal_Api( 'check', $credentials->get_api_credential(), $order_id );
						$response           	= $request->get_response_message();

						if ( 'completed' === $new_status && 'EMPTY' !== $response && 'ACTIVE' === $response->result->status ) {
							$subscribe_status 	= $response->result->status;// true.
							$expired          	= $response->result->billing_info->next_billing_time;
							$expired          	= ! empty( $expired ) ? new DateTime( $expired ) : $expired;
							$expired          	= is_object( $expired ) ? $expired->format( 'Y-m-d H:i:s' ) : $expired;
							$expired          	= jpw_convert_payment_time( $expired, $credentials->get_payment_timezone() );
							$completed        	= true;
						} elseif ( 'cancelled' === $new_status || 'refunded' === $new_status || 'failed' === $new_status ) {

							if ( get_post_meta( $order_id, 'jeg_paywall_completed', true ) === 'yes' ) {
								$expired   = false;
								$completed = false;
							}
						}
					}

					if ( $stripesubscribe_id ) {
						$credentials        	= new JPW_Stripe();
						$request            	= new Stripe_Api( 'check', $credentials->get_api_credential(), $order_id );
						$response           	= $request->get_response_message();
						$response           	= json_decode( json_encode( $response ), false );

						if ( 'completed' === $new_status && isset( $response->status ) && 'active' === $response->status ) {
							$subscribe_status 	= 'ACTIVE';
							$expired 			= new DateTime();
							$expired 			= $expired->setTimestamp( $data->current_period_end );
							$expired 			= $expired->setTimezone( new DateTimeZone( 'UTC' ) );
							$expired 			= $expired->format( 'Y-m-d H:i:s' );
							$completed        	= true;
						} elseif ( 'cancelled' === $new_status || 'refunded' === $new_status || 'failed' === $new_status ) {

							if ( get_post_meta( $order_id, 'jeg_paywall_completed', true ) === 'yes' ) {
								$expired   = false;
								$completed = false;
							}
						}
					}

				}

				// check if product is paywall_unlock.
				if ( $product->is_type( 'paywall_unlock' ) && $user_id > 0 ) {
					$is_paywall = true;
					if ( 'completed' === $new_status ) {
						$unlock_remaining += $product->get_total_unlock() * $item->get_quantity();
						$completed        = true;
					} elseif ( 'cancelled' === $new_status || 'refunded' === $new_status || 'failed' === $new_status ) {
						if ( get_post_meta( $order_id, 'jeg_paywall_completed', true ) === 'yes' ) {
							if ( $unlock_remaining >= $product->get_total_unlock() * $item->get_quantity() ) {
								$unlock_remaining -= $product->get_total_unlock() * $item->get_quantity();
							} else {
								$leftover = $product->get_total_unlock() * $item->get_quantity() - $unlock_remaining;
								$unlock_remaining = 0;
								// lock post that has been unlocked
								for ( $i = 0; $i < $leftover; $i++ ) {
									array_shift( $unlocked_posts );
								}
							}
							$completed = false;
						}
					}
				}
			}

			if ( $is_paywall ) {
				if ( $completed ) {
					update_post_meta( $order_id, 'jeg_paywall_completed', 'yes' );
				} else {
					update_post_meta( $order_id, 'jeg_paywall_completed', 'no' );
				}

				if ( ! empty( $paypalsubscribe_id ) ) {
					$paywall_user_data['jpw_paypal_subs_id'] = $paypalsubscribe_id;
					$paywall_user_data['subscribe_status']   = $subscribe_status;
					$paywall_user_data['expired_date']       = $expired;
				} elseif ( ! empty( $stripesubscribe_id ) ) {
					$paywall_user_data['jpw_stripe_subs_id'] = $stripesubscribe_id;
					$paywall_user_data['subscribe_status']   = $subscribe_status;
					$paywall_user_data['expired_date']       = $expired;
				}
				else {
					$paywall_user_data['unlock_remaining'] 	= $unlock_remaining;
					$paywall_user_data['unlocked_posts']  	= $unlocked_posts;
				}

				$this->update_paywall_data( $paywall_user_data, $user_id );
			}
		}
	}

	/**
	 * Update User Data
	 *
	 * @param array $paywall
	 * @param int $user_id
	 */
	protected function update_paywall_data( $paywall, $user_id ) {
		if ( isset( $paywall['jpw_paypal_subs_id'] ) ) { // subscription meta.
			update_user_option( $user_id, 'jpw_subscribe_status', $paywall['subscribe_status'] );
			update_user_option( $user_id, 'jpw_expired_date', $paywall['expired_date'] );
			update_user_option( $user_id, 'jpw_paypal_subs_id', $paywall['jpw_paypal_subs_id'] );
		} elseif ( isset( $paywall['jpw_stripe_subs_id'] ) ) { // subscription meta.
			update_user_option( $user_id, 'jpw_subscribe_status', $paywall['subscribe_status'] );
			update_user_option( $user_id, 'jpw_expired_date', $paywall['expired_date'] );
			update_user_option( $user_id, 'jpw_stripe_subs_id', $paywall['jpw_stripe_subs_id'] );
		} else { // unlock meta.
			update_user_option( $user_id, 'jpw_unlock_remaining', $paywall['unlock_remaining'] );
			update_user_option( $user_id, 'jpw_unlocked_post_list', $paywall['unlocked_posts'] );
		}
	}

	/**
	 * Check if user allowed to purchase
	 *
	 * @param $product_id
	 *
	 * @return bool
	 */
	protected function allow_purchase( $product_id ) {
		// Add codes here if need to restrict user from purchasing.

		return true;
	}
}
