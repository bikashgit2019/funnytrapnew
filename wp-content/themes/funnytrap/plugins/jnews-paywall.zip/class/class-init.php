<?php
/**
 * JNews Paywall Class
 *
 * @author Jegtheme
 * @since 1.0.0
 * @package jnews-paywall
 */

namespace JNews\Paywall;

use DateInterval;
use DateTime;
use DateTimeZone;
use Exception;
use JNews\Paywall\Gateways\Paypal\Paypal_Api;
use JNews\Paywall\Gateways\Stripe\Stripe_Api;
use JPW_Gateways;
use JNews\Paywall\Ajax_Handler;
use JNews\Paywall\Customizer\Customizer;
use JNews\Paywall\Element\Register_Elements;
use JNews\Paywall\Status\Frontend_Status;
use JNews\Paywall\Metabox\Metabox;
use JNews\Paywall\Woocommerce\Order;
use JNews\Paywall\Woocommerce\Product;
use JNews\Paywall\Truncater\Truncater;
use JPW_Paypal;
use JPW_Stripe;
use WP_User_Query;


/**
 * Class Init
 *
 * @package JNews\Paywall
 */
class Init {

	/**
	 * @var Init
	 */
	private static $instance;

	/**
	 * Init constructor.
	 */
	private function __construct() {
		$this->setup_init();
		$this->setup_hook();
		$this->register_gateway();
	}

	/**
	 * Setup Classes
	 */
	private function setup_init() {
		Ajax_Handler::instance();
		Customizer::instance();
		Register_Elements::instance();
		Frontend_Status::instance();
		Metabox::instance();
		Order::instance();
		Product::instance();
		Truncater::instance();
	}

	/**
	 * Setup Hooks
	 */
	private function setup_hook() {
		add_action( 'init', [ $this, 'load_templates' ] );
		add_action( 'plugins_loaded', [ $this, 'load_plugin_textdomain' ] );
		add_action( 'init', [ $this, 'update_user_status' ] );
		add_action( 'wp_print_styles', [ $this, 'load_frontend_css' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'editor_style' ], 99 );
		add_action( 'admin_enqueue_scripts', [ $this, 'editor_style' ], 99 );
		add_action( 'admin_enqueue_scripts', [ $this, 'load_admin_script' ] );
		add_action( 'plugins_loaded', [ $this, 'load_woocommerce_class' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'load_frontend_script' ] );
	}

	/**
	 * Register Gateway Class
	 */
	private function register_gateway() {
		include_once JNEWS_PAYWALL_DIR . 'class/gateways/class-jpw-gateways.php';
		JPW_Gateways::instance();
	}

	/**
	 * @return Init
	 */
	public static function instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	/**
	 * Load JNews Paywall Woocommerce Classes
	 */
	public function load_woocommerce_class() {
		if ( class_exists( 'WC_Product' ) ) {
			require_once JNEWS_PAYWALL_DIR . 'class/woocommerce/class-wc-product-paywall-subscribe.php';
			require_once JNEWS_PAYWALL_DIR . 'class/woocommerce/class-wc-product-paywall-unlock.php';
		}
	}

	/**
	 * Load Frontend CSS
	 */
	public function load_frontend_css() {
		wp_enqueue_style( 'jnews-paywall', JNEWS_PAYWALL_URL . '/assets/css/jpw-frontend.css', null, JNEWS_PAYWALL_VERSION );
	}

	/**
	 * Load editor style
	 */
	public function editor_style() {
		wp_enqueue_style( 'jnews-paywall-admin', JNEWS_PAYWALL_URL . '/assets/css/admin/admin-style.css', null, JNEWS_PAYWALL_VERSION );
	}

	/**
	 * Load Admin CSS
	 */
	public function load_admin_script() {
		wp_enqueue_style( 'jnews-paywall', JNEWS_PAYWALL_URL . '/assets/css/jpw-admin.css', null, JNEWS_PAYWALL_VERSION );
		wp_enqueue_script( 'jnews-paywall', JNEWS_PAYWALL_URL . '/assets/js/admin.js', null, JNEWS_PAYWALL_VERSION, true );
	}

	/**
	 * Load Frontend Script
	 */
	public function load_frontend_script() {
		wp_enqueue_script( 'jnews-paywall', JNEWS_PAYWALL_URL . '/assets/js/frontend.js', null, JNEWS_PAYWALL_VERSION, true );
	}

	/**
	 * Load Template
	 */
	public function load_templates() {
		// update_user_option( get_current_user_id(), 'jpw_unlock_remaining', 0 );
		// update_user_option( get_current_user_id(), 'jpw_unlocked_post_list', [] );
		$templates = [
			'admin-menu.php',
			'popup-form.php',
		];

		foreach ( $templates as $template ) {
			$template = JNEWS_PAYWALL_DIR . 'template/' . $template;

			if ( ! empty( $template ) && file_exists( $template ) ) {
				include $template;
			}
		}
	}

	/**
	 * Load Text Domain
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain( JNEWS_PAYWALL, false, basename( JNEWS_PAYWALL_DIR ) . '/languages/' );
	}


	/**
	 * Update User status
	 *
	 * @throws Exception
	 */
	public function update_user_status() {
		// New Check for Expired.
		$subscribe_status = get_user_option( 'jpw_subscribe_status', get_current_user_id() );
		$expired          = get_user_option( 'jpw_expired_date', get_current_user_id() ) ? get_user_option( 'jpw_expired_date', get_current_user_id() ) : Date( 'F d, Y' );
		if ( ! empty( $subscribe_status ) && $subscribe_status && 'ACTIVE' === $subscribe_status ) {
			$current_date = new DateTime();
			$expired_date = new DateTime( $expired );
			$expired_date->add( new DateInterval( 'PT1H' ) ); // We need to wait for recurring payment.
			if ( $current_date >= $expired_date ) {
				update_user_option( get_current_user_id(), 'jpw_subscribe_status', false );
				update_user_option( get_current_user_id(), 'jpw_expired_date', false );
			}
		}
	}
}
