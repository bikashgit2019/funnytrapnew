<?php

namespace JNews\Paywall\Gateways\Stripe\Lib\Exception;

class Unexpected_Value_Exception extends \UnexpectedValueException implements Exception_Interface {

}
