<?php

namespace JNews\Paywall\Gateways\Stripe\Lib;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class Bitcoin_Transaction extends Api_Resource {

	const OBJECT_NAME = 'bitcoin_transaction';
}
