Change Logs :

== 7.0.1 ==
- [BUG] Fix active plugin issue

== 7.0.0 ==
- First Release