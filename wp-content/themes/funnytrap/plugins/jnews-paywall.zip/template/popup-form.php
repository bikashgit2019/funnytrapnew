<?php

add_action( 'wp_footer', 'render_jnews_paywall_popup' );
function render_jnews_paywall_popup() {
	/**
	 * Unlock Popup
	 */
	$unlock_remaining = get_user_option( 'jpw_unlock_remaining', get_current_user_id() ) ? get_user_option( 'jpw_unlock_remaining', get_current_user_id() ) : 0;
	$unlock_popup     = '<div id=\'jpw_unlock_popup\' class=\'jeg_popup mfp-with-anim mfp-hide\'>
                        <div class=\'jpw_popup\'>
                            <h5>' . esc_html__( 'Are you sure want to unlock this post?', 'jnews-paywall' ) . '</h5>
                            <span>' . esc_html__( 'Unlock left', 'jnews-paywall' ) . ' : ' . $unlock_remaining . '</span>
                            <button type=\'button\' class=\'btn yes\'><span>' . esc_html__( 'Yes', 'jnews-paywall' ) . '</span><i class="fa fa-spinner fa-pulse" style="display: none;"></i></button>
                            <button type=\'button\' class=\'btn no\'>' . esc_html__( 'No', 'jnews-paywall' ) . '</button>
                        </div>
                    </div>';

	echo $unlock_popup;

	/**
	 * Cancel Subs Popup
	 */
	$cancel_subs = '<div id=\'jpw_cancel_subs_popup\' class=\'jeg_popup mfp-with-anim mfp-hide\'>
                        <div class=\'jpw_popup\'>
                            <h5>' . esc_html__( 'Are you sure want to cancel subscription?', 'jnews-paywall' ) . '</h5>
                            <button type=\'button\' class=\'btn yes\'><span>' . esc_html__( 'Yes', 'jnews-paywall' ) . '</span><i class="fa fa-spinner fa-pulse" style="display: none;"></i></button>
                            <button type=\'button\' class=\'btn no\'>' . esc_html__( 'No', 'jnews-paywall' ) . '</button>
                        </div>
                    </div>';

	echo $cancel_subs;
}
