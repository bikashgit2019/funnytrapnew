Change Log :

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.2 ==
- [BUG] Fix issue with implode() function PHP 7.4

== 6.0.1 ==
- [IMPROVEMENT] Update analytics script code

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.3 ==
- [IMPROVEMENT] Use .on()

== 5.0.2 ==
- [IMPROVEMENT] Testing with Envato Theme Check plugin

== 5.0.1 ==
- [IMPROVEMENT] Move framework to JNews Essential

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.1 ==
- [BUG] Fix header builder issue with Polylang

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
